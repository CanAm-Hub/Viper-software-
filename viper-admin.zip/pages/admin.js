import { useEffect, useMemo, useState } from "react";

export default function Admin() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedNumber, setSelectedNumber] = useState("");
  const [outgoing, setOutgoing] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const res = await fetch("/api/leads");
      const data = await res.json();
      setMessages(data.messages || []);
      setLoading(false);
    };
    load();
  }, []);

  const contacts = useMemo(() => {
    const map = new Map();
    messages.forEach(m => {
      const peer = m.direction === "inbound" ? m.from : m.to;
      if (!map.has(peer)) {
        map.set(peer, { number: peer, last: m.dateCreated, lastBody: m.body });
      } else {
        const cur = map.get(peer);
        if (new Date(m.dateCreated) > new Date(cur.last)) {
          cur.last = m.dateCreated;
          cur.lastBody = m.body;
        }
      }
    });
    return Array.from(map.values()).sort((a,b)=>new Date(b.last)-new Date(a.last));
  }, [messages]);

  const thread = useMemo(() => {
    if (!selectedNumber) return [];
    return messages.filter(m => (m.from === selectedNumber || m.to === selectedNumber))
                   .sort((a,b)=> new Date(a.dateCreated)-new Date(b.dateCreated));
  }, [messages, selectedNumber]);

  const send = async (e) => {
    e.preventDefault();
    if (!selectedNumber || !outgoing) return;
    setSending(true);
    const res = await fetch("/api/send", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ to: selectedNumber, body: outgoing })
    });
    const data = await res.json();
    setSending(false);
    if (!data.error) {
      setOutgoing("");
      const r = await fetch("/api/leads");
      const d = await r.json();
      setMessages(d.messages || []);
    }
  };

  return (
    <div className="container">
      <div className="header">
        <h1 className="logo"><span className="v">VIPER</span> <span className="s">Software</span> / Admin</h1>
        <span className="badge">{contacts.length} contacts</span>
      </div>

      <div className="card" style={{display:"grid", gridTemplateColumns:"280px 1fr", gap:"16px"}}>
        <div>
          <h3>Contacts</h3>
          {loading ? <p>Loading…</p> : contacts.length === 0 ? <p>No messages yet.</p> : null}
          <ul style={{listStyle:"none", padding:0, margin:0}}>
            {contacts.map(c => (
              <li key={c.number} style={{padding:"8px", borderBottom:"1px solid #eee", cursor:"pointer", background:selectedNumber===c.number?"#f8fafc":"#fff"}}
                  onClick={()=>setSelectedNumber(c.number)}>
                <div style={{fontWeight:600}}>{c.number}</div>
                <div style={{fontSize:12, color:"#555"}}>{new Date(c.last).toLocaleString()} – {c.lastBody?.slice(0,50)}</div>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3>Conversation</h3>
          {!selectedNumber ? <p>Select a contact to view messages.</p> :
            <div>
              <div className="card" style={{maxHeight:"50vh", overflowY:"auto", marginBottom:12}}>
                {thread.map((m,i)=>(
                  <div key={m.sid || i} style={{margin:"8px 0"}}>
                    <div className="badge" style={{background: m.direction==="inbound" ? "#e2e8f0" : "#d1fae5"}}>
                      {m.direction}
                    </div>
                    <div className="mono" style={{marginTop:4}}>{m.body}</div>
                    <div style={{fontSize:12, color:"#666"}}>{new Date(m.dateCreated).toLocaleString()}</div>
                  </div>
                ))}
              </div>
              <form onSubmit={send} style={{display:"flex", gap:8}}>
                <input className="input" value={outgoing} onChange={e=>setOutgoing(e.target.value)} placeholder={"Message to " + selectedNumber} />
                <button className="btn" disabled={sending || !outgoing}>{sending ? "Sending…" : "Send"}</button>
              </form>
            </div>
          }
        </div>
      </div>

      <div style={{marginTop:16}} className="card">
        <h3>No database needed</h3>
        <p>Viper reads your recent Twilio message logs to build contacts and threads. Outbound messages are sent via Twilio. For auto-replies, set your Twilio phone number's messaging webhook to <code className="mono">/api/inbound-sms</code> after deploy.</p>
      </div>
    </div>
  );
}
