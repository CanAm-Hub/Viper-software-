import Link from "next/link";
import { useState } from "react";

export default function Home() {
  const [to, setTo] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState("");

  const sendTest = async (e) => {
    e.preventDefault();
    setSending(true);
    setStatus("");
    const res = await fetch("/api/send", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ to, body: body || "Viper test message ✅" })
    });
    const data = await res.json();
    setSending(false);
    setStatus(data.error ? `Error: ${data.error}` : "Message sent ✔️");
  };

  return (
    <div className="container">
      <div className="header">
        <div className="logo"><span className="v">VIPER</span> <span className="s">Software</span></div>
        <Link className="btn" href="/admin">Open Admin</Link>
      </div>

      <div className="card">
        <h2>Lead Capture / Test Sender</h2>
        <p>Use this to send yourself a test SMS via Twilio after you deploy. (This helps verify your keys.)</p>
        <form onSubmit={sendTest}>
          <div style={{margin:"8px 0"}}>
            <label>Phone number (E.164, e.g. +18335551234)</label>
            <input className="input" value={to} onChange={e=>setTo(e.target.value)} placeholder="+1..." />
          </div>
          <div style={{margin:"8px 0"}}>
            <label>Message</label>
            <textarea className="textarea" rows={3} value={body} onChange={e=>setBody(e.target.value)} placeholder="Your message..." />
          </div>
          <button disabled={sending} className="btn">{sending ? "Sending..." : "Send Test SMS"}</button>
        </form>
        {status && <p style={{marginTop:10}} className="mono">{status}</p>}
      </div>

      <div style={{marginTop:16}} className="card">
        <h3>After deploy:</h3>
        <ol>
          <li>Twilio → Your Phone Number → Messaging webhook</li>
          <li>Set to <code className="mono">https://YOURDOMAIN.vercel.app/api/inbound-sms</code> (HTTP POST)</li>
          <li>This enables auto-replies & conversation capture.</li>
        </ol>
      </div>
    </div>
  );
}
