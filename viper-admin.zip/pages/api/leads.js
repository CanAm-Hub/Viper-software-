import { getTwilioClient, getTwilioFrom } from "@/lib/twilio";

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  try {
    const client = getTwilioClient();
    const { from } = getTwilioFrom();

    const since = new Date(Date.now() - 14*24*60*60*1000);
    const messages = await client.messages.list({ dateSentAfter: since, pageSize: 100 });

    const filtered = messages.filter(m => (m.to === from || m.from === from)).map(m => ({
      sid: m.sid,
      from: m.from,
      to: m.to,
      body: m.body,
      dateCreated: m.dateCreated,
      direction: m.direction,
      status: m.status
    }));

    res.status(200).json({ messages: filtered });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}
