import { getTwilioClient, getTwilioFrom } from "@/lib/twilio";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { to, body } = req.body || {};
    if (!to || !body) return res.status(400).json({ error: "Missing 'to' or 'body'." });

    const client = getTwilioClient();
    const fromConfig = getTwilioFrom();
    const msg = await client.messages.create({
      body,
      ...(fromConfig.messagingServiceSid ? { messagingServiceSid: fromConfig.messagingServiceSid } : { from: fromConfig.from }),
      to
    });

    res.status(200).json({ sid: msg.sid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}
