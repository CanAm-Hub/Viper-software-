import { twiml as Twiml } from "twilio";

export const config = { api: { bodyParser: { sizeLimit: "1mb" } } };

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");
  const incoming = (req.body.Body || "").trim().toLowerCase();

  let reply = "Thanks for reaching out! Reply 1 for info, 2 for a callback, STOP to opt-out.";
  if (incoming === "1") reply = "Here’s the info: we’ll text you details shortly. Any specific questions?";
  else if (incoming === "2") reply = "Got it. What’s a good time for a quick call?";
  else if (incoming.includes("stop")) reply = "You’re opted out. You won’t receive more texts.";

  const twiml = new Twiml.MessagingResponse();
  twiml.message(reply);

  res.setHeader("Content-Type", "text/xml");
  res.status(200).send(twiml.toString());
}
